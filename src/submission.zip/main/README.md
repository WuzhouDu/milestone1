# Introduction
This is a repository for the project milestone 1 of the course UCSD 25 winter CSE232B, which implements a XPath query evaluator for XML file.

# Team Members
only myself

# How to run the code
1. Clone the repository
2. Run the following command to compile the code:
```
javac *.java
java EvaluatorTest
```
then it will ask for an input XPath query. You can input the query and it will output the result xml file to `output.xml`.

e.g. input `doc("j_caesar.xml")//PERSONA`.

